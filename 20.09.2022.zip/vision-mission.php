<?php include('partials/header-about.php'); ?>

<!-- <section id="Page-heading" class="admission-page d-flex align-items-center">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Little Jewels School</h2>
            </div>
        </div>
    </div>
</section>

<section id="Page-content">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="side-menu">
                    <ul>
                        <li><a href="about.php">About LJS</a></li>
                        <li class="active"><a href="vision-mission.php">Mission and Vision</a></li>
                        <li><a href="message.php">Message</a></li>
                        <li><a href="history.php">History</a></li>
                        <li><a href="core-values.php">Core Values</a></li>
                        <li><a href="campus-facilities.php">Campus Facilities</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-8">
                <h3>Mission and Vision</h3>
                <p>We are concerned with the provision of appropriate educational opportunities to develop the student’s skill related to their age, aptitude, ability and English language proficiency. This may help them to attain the capabilities to face their future with a strong, well rounded education. A well balanced education caters to the need of a child to develop his/her identity, character, personality and individuality. Little Jewels is geared to face these challenges in shaping the lives of students. Discipline, honesty, responsiveness and enthusiasm are the key points in a student’s life. Let us — you and we unite in our mission to give these young children a healthier, brighter, secure and disciplined tomorrow — A tomorrow free from violence, abuse, destruction and corruption.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">

            </div>
        </div>
    </div>
</section> -->

<?php include('partials/footer.php'); ?>