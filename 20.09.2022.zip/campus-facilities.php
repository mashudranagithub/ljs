<?php include('partials/header-about.php'); ?>

<!-- <section id="Page-heading" class="admission-page d-flex align-items-center">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Little Jewels School</h2>
            </div>
        </div>
    </div>
</section>

<section id="Page-content">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="side-menu">
                    <ul>
                        <li><a href="about.php">About LJS</a></li>
                        <li><a href="vision-mission.php">Mission and Vision</a></li>
                        <li><a href="message.php">Message</a></li>
                        <li><a href="history.php">History</a></li>
                        <li><a href="core-values.php">Core Values</a></li>
                        <li class="active"><a href="campus-facilities.php">Campus Facilities</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-8">
                <h3>Little Jewels School Campus Facilities</h3>
                <p></p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">

            </div>
        </div>
    </div>
</section> -->

<?php include('partials/footer.php'); ?>