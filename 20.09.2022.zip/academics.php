<?php include('partials/header-academics.php'); ?>



<?php include('partials/footer.php'); ?>