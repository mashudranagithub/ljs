<?php include('partials/header-academics.php'); ?>

<!-- <section id="Page-heading" class="admission-page d-flex align-items-center">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Admission</h2>
            </div>
        </div>
    </div>
</section>

<section id="Page-content">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="side-menu">
                    <ul>
                        <li><a href="admission-info.php">Admission Information</a></li>
                        <li><a href="admission-form.php">Admission Form</a></li>
                        <li class="active"><a href="rules-regulations.php">Rules & Regulations</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-8">
                <h3>Rules & Regulations</h3>
                <ol>
                    <li>Parents are requested to take a keen interest in the education of their children. They are asked to see that children’s homework is prepared.</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">

            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-12">
                <h3>Contact Information</h3>
                <div class="contacts">
                    <div class="row no-gutters">
                        <div class="col-md-4">
                            <div class="single-contact">
                                <h6>Junior Section</h6>
                                <p><b>Name: </b>Md. Mashud Rana</p>
                                <p><b>Phone: </b>+8801918631391</p>
                                <p><b>Email: </b>mashudtech@gmail.com</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="single-contact">
                                <h6>Junior Section</h6>
                                <p><b>Name: </b>Md. Mashud Rana</p>
                                <p><b>Phone: </b>+8801918631391</p>
                                <p><b>Email: </b>mashudtech@gmail.com</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="single-contact">
                                <h6>Junior Section</h6>
                                <p><b>Name: </b>Md. Mashud Rana</p>
                                <p><b>Phone: </b>+8801918631391</p>
                                <p><b>Email: </b>mashudtech@gmail.com</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> -->

<?php include('partials/footer.php'); ?>